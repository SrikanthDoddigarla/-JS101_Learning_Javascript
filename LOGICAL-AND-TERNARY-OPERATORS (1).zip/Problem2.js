let c="e";
if (c=="a"||c=="e"||c=="i"||c=="o"||c=="u") {
  console.log("Vowel");
}else{
  console.log("Consonants")
}