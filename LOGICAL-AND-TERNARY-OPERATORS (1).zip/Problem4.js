let a=20;
let b=30;
let c=40;
a>b&&a>c ? console.log("a is greatest")
  : b>c&&b>a? console.log("b is greatest")
  : console.log("c is greatest")