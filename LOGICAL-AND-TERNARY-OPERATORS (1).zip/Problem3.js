let c="b";
if (c!="a"||c!="e"||c!="i"||c!="o"||c!="u") {
  console.log("Consonants");
}else{
  console.log("Vowels")
}