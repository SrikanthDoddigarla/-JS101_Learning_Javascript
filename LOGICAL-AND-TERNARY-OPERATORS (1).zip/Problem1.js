let  yob=1995;
let  age=2022-yob;
if (age>=13&&age<=19) {
  console.log("Teenager");
  
}else if (age>=20&&age<=29);{
console.log("Twenties")
}