let day="mon";
switch(day) { 
  case "sun":console.log("sunday");
  break;
  case "mon":console.log("monday");
  break;
  case "tue":console.log("tuesday");
  break;
  case "wed":console.log("wednesday");
  break;
  case "thur":console.log("thursday");
  break;
  case "fri":console.log("friday");
  break;
  case "sat":console.log("saturday");
  break;
}    