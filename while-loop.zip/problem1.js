
let a=0;
while(a<=10) {
  if(a%2!=0){
    console.log(a);
  }
  a++
}